(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f0026_next_dist_compiled_36642510._.js",
  "static/chunks/f0026_next_dist_shared_lib_bc7e0896._.js",
  "static/chunks/f0026_next_dist_client_c89144f0._.js",
  "static/chunks/f0026_next_dist_80bd497f._.js",
  "static/chunks/f0026_next_app_6f2f4b8f.js",
  "static/chunks/[next]_entry_page-loader_ts_048d4072._.js",
  "static/chunks/76102_react-dom_44795136._.js",
  "static/chunks/node_modules__pnpm_7136f466._.js",
  "static/chunks/[root-of-the-server]__45f039c3._.js"
],
    source: "entry"
});
