(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f0026_next_dist_compiled_36642510._.js",
  "static/chunks/f0026_next_dist_shared_lib_e3ec8eb5._.js",
  "static/chunks/f0026_next_dist_client_c89144f0._.js",
  "static/chunks/f0026_next_dist_10689c54._.js",
  "static/chunks/f0026_next_error_a4ae2873.js",
  "static/chunks/[next]_entry_page-loader_ts_14809c7a._.js",
  "static/chunks/76102_react-dom_44795136._.js",
  "static/chunks/node_modules__pnpm_7136f466._.js",
  "static/chunks/[root-of-the-server]__092393de._.js"
],
    source: "entry"
});
