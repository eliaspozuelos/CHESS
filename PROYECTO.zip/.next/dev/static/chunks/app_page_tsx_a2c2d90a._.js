(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_ec460e4d._.js",
  "static/chunks/node_modules__pnpm_1dd23057._.js"
],
    source: "dynamic"
});
