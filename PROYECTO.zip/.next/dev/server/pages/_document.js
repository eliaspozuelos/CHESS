var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/node_modules__pnpm_3eb86003._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.m("[project]/node_modules/.pnpm/next@16.0.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/node_modules/.pnpm/next@16.0.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/document.js [ssr] (ecmascript)").exports
