globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/f0026_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_17d3200c._.js",
    "static/chunks/f0026_next_dist_compiled_react-dom_0166b3d9._.js",
    "static/chunks/f0026_next_dist_compiled_react-server-dom-turbopack_0275a907._.js",
    "static/chunks/f0026_next_dist_compiled_next-devtools_index_d87c60d3.js",
    "static/chunks/f0026_next_dist_compiled_c5efbfee._.js",
    "static/chunks/f0026_next_dist_client_fd07184e._.js",
    "static/chunks/f0026_next_dist_024d02af._.js",
    "static/chunks/69652_@swc_helpers_cjs_679851cc._.js",
    "static/chunks/_a0ff3932._.js",
    "static/chunks/turbopack-_3d754327._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];