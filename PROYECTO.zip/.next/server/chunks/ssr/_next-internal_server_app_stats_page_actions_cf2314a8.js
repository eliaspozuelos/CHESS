module.exports=[28799,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_stats_page_actions_cf2314a8.js.map