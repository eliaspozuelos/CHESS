globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/10ff75e2073ef7ac.js",
    "static/chunks/42dfdd8807fe5ba7.js",
    "static/chunks/e16a35b1ff155694.js",
    "static/chunks/b77f9c0ff60d6c8f.js",
    "static/chunks/turbopack-8041fef4875da852.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];